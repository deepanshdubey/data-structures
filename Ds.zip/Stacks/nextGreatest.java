import java.io.*;
import java.util.*;

class nextGreatest
{
    public static void main(String[] args) throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Stack <Integer> st = new Stack<>();



        

    }
}